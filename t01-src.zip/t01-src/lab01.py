# File: lab01.py

# Replace the following by your full name and 8-digit student number
student_name = "Chan Tai Man"
student_id = "01234567"

from random import random

def palindrome_recur(s):
    pass  # replace this line by your code

def myth_value(n):
    pass  # replace this line by your code

if __name__ == "__main__":
    pass  # replace this line by your code (if necessary)
