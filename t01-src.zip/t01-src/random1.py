# File: random1.py
from random import random  # I.e. from module_name import function_name
print(random())            # I.e. function_name()
