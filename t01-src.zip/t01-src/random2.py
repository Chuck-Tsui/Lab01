# File: random2.py
import random           # I.e. import module_name
print(random.random())  # I.e. module_name.function_name()
